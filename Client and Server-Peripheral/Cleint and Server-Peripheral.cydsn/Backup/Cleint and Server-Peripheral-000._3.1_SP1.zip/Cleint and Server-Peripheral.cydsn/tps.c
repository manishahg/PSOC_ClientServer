/*******************************************************************************
* File Name: tps.c
*
* Description:
*  This file contains Tx Power Service callback handler function.
* 
********************************************************************************
* Copyright 2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include <common.h>
#include <stdio.h>


/*******************************************************************************
* Function Name: TpsServiceAppEventHandler
********************************************************************************
*
* Summary:
*  This is an event callback function to receive events from the BLE Component,
*  which are specific to Tx Power Service.
*
* Parameters:
*  uint8 event:       Write Command event from the CYBLE component.
*  void* eventParams: A structure instance of CYBLE_GATT_HANDLE_VALUE_PAIR_T
*                     type.
*
* Return:
*  None
*
*******************************************************************************/
void TpsServiceAppEventHandler(uint32 event, void *eventParam)
{
    switch(event)
    {
        /***************************************
        *        TPS Server events
        ***************************************/
        case CYBLE_EVT_TPSS_NOTIFICATION_ENABLED:
            printf("TPS notification enabled\r\n");
            break;
        case CYBLE_EVT_TPSS_NOTIFICATION_DISABLED:
            printf("TPS notification disabled\r\n");
            break;
        default:
            break;
    }
}


/*******************************************************************************
* Function Name: ConvertTxPowerlevelToInt8
********************************************************************************
*
* Summary:
*  Converts Tx Power Level from CYBLE_BLESS_PWR_LVL_T to int8.
*
* Parameters:
*  CYBLE_BLESS_PWR_LVL_T pwrLevel: value to be converted to int8
*
* Return:
*   None
*
*******************************************************************************/
int ConvertTxPowerlevelToInt8(CYBLE_BLESS_PWR_LVL_T pwrLevel)
{
    int8 intPwrLevel = 0;

    switch (pwrLevel)
    {
        case CYBLE_LL_PWR_LVL_NEG_18_DBM:
            intPwrLevel = -18;
            break;
        case CYBLE_LL_PWR_LVL_NEG_12_DBM:
            intPwrLevel = -12;
            break;
        case CYBLE_LL_PWR_LVL_NEG_6_DBM:
            intPwrLevel = -6;
            break;
        case CYBLE_LL_PWR_LVL_NEG_3_DBM:
            intPwrLevel = -3;
            break;
        case CYBLE_LL_PWR_LVL_NEG_2_DBM:
            intPwrLevel = -2;
            break;
        case CYBLE_LL_PWR_LVL_NEG_1_DBM:
            intPwrLevel = -1;
            break;
        case CYBLE_LL_PWR_LVL_0_DBM:
            intPwrLevel = 0;
        case CYBLE_LL_PWR_LVL_3_DBM:
            intPwrLevel=3;
            break;

        default:
            break;
    }

    return(intPwrLevel);
}


/*******************************************************************************
* Function Name: DecreaseTxPowerLevelValue
********************************************************************************
*
* Summary:
*  Decreases the Tx Power level by one scale lower.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void DecreaseTxPowerLevelValue(CYBLE_BLESS_PWR_LVL_T * pwrLevel)
{
    switch (*pwrLevel)
    {
        case CYBLE_LL_PWR_LVL_NEG_18_DBM:
            *pwrLevel = CYBLE_LL_PWR_LVL_NEG_18_DBM;
            break;
        case CYBLE_LL_PWR_LVL_NEG_12_DBM:
            *pwrLevel = CYBLE_LL_PWR_LVL_NEG_18_DBM;
            break;
        case CYBLE_LL_PWR_LVL_NEG_6_DBM:
            *pwrLevel = CYBLE_LL_PWR_LVL_NEG_12_DBM;
            break;
        case CYBLE_LL_PWR_LVL_NEG_3_DBM:
            *pwrLevel = CYBLE_LL_PWR_LVL_NEG_6_DBM;
            break;
        case CYBLE_LL_PWR_LVL_NEG_2_DBM:
            *pwrLevel = CYBLE_LL_PWR_LVL_NEG_3_DBM;
            break;
        case CYBLE_LL_PWR_LVL_NEG_1_DBM:
            *pwrLevel = CYBLE_LL_PWR_LVL_NEG_2_DBM;
            break;
        case CYBLE_LL_PWR_LVL_0_DBM:
            *pwrLevel = CYBLE_LL_PWR_LVL_NEG_1_DBM;
            break;
        case CYBLE_LL_PWR_LVL_3_DBM:
            *pwrLevel=CYBLE_LL_PWR_LVL_0_DBM;
            break;

        default:
            break;
    }
}


/* [] END OF FILE */
